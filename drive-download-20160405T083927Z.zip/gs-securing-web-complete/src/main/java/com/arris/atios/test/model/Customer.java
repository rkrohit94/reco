package com.arris.atios.test.model;

import org.springframework.data.annotation.Id;
import org.springframework.stereotype.Repository;

@Repository
public class Customer {

	@Id
	private String id;

	private String firstName;
	private String companyEmail;
	private String userPassword;

	public Customer() {

	}

	public Customer(String firstName, String companyEmail, String userPassword) {
		super();
		this.firstName = firstName;
		this.companyEmail = companyEmail;
		this.userPassword = userPassword;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getCompanyEmail() {
		return companyEmail;
	}

	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", firstName=" + firstName + ", companyEmail=" + companyEmail + ", userPassword="
				+ userPassword + "]";
	}

}
