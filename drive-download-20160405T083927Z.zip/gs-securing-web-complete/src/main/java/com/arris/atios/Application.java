package com.arris.atios;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.arris.atios.test.model.Customer;
import com.arris.atios.test.model.dao.CustomerRepository;

@SpringBootApplication
public class Application implements CommandLineRunner{
	
	@Autowired
	CustomerRepository repository;

    public static void main(String[] args) throws Throwable {
        SpringApplication.run(Application.class, args);
    }
    
    @Override
	public void run(String... args) throws Exception {

    	repository.deleteAll();

		repository.save(new Customer("Arris","alice", "smith"));
		

		System.out.println("Customers found with findAll():");
		System.out.println("-------------------------------");
		for (Customer customer : repository.findAll()) {
			System.out.println(customer);
		}
		System.out.println();

		// fetch an individual customer
		System.out.println("Customer found with findByFirstName('alice'):");
		System.out.println("--------------------------------");
		System.out.println(repository.findByCompanyEmail("alice"));

		
		
	}


}
