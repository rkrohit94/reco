package com.arris.atios.test.model.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.arris.atios.test.model.Customer;


public interface CustomerRepository extends MongoRepository<Customer, String> {

    public Customer findByCompanyEmail(String email);
   
}
